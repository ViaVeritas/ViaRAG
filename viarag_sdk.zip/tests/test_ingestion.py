
from viarag.core.ingestion import SimpleTextIngestor

def test_ingestion():
    ingestor = SimpleTextIngestor()
    # Assume a test directory with .txt files is present in tests/test_docs/
    documents = ingestor.ingest("tests/test_docs")
    assert isinstance(documents, list)
