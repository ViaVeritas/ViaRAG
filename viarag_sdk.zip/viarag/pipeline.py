
from .core.ingestion import SimpleTextIngestor

class ViaRAG:
    def __init__(self):
        self.ingestor = SimpleTextIngestor()

    def ingest(self, path: str):
        return self.ingestor.ingest(path)
