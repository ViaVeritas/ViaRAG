
from typing import Optional, Dict

class Document:
    def __init__(self, content: str, metadata: Optional[Dict] = None):
        self.content = content
        self.metadata = metadata or {}

    def __repr__(self):
        return f"<Document length={len(self.content)} metadata={self.metadata}>"
