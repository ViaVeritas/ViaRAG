
import os
from typing import List
from .document import Document

class SimpleTextIngestor:
    def ingest(self, path: str) -> List[Document]:
        """
        Ingests all .txt files from the given directory path.
        """
        documents = []
        for filename in os.listdir(path):
            if filename.endswith(".txt"):
                with open(os.path.join(path, filename), 'r', encoding='utf-8') as f:
                    content = f.read()
                documents.append(Document(content, metadata={"filename": filename}))
        return documents
